import React from 'react'

function PersonDetail() {
  return (
    <div>PersonDetail</div>
  )
}

export default PersonDetail